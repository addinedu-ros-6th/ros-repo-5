# minibot_description

## View robot

```shell
$ ros2 launch minibot_description view_robot.launch.py
```

<center><img src="../docs/view_robot.png" width="50%"/></center>

<center><img src="../docs/view_robot_joint_states.png" width="30%"/></center>
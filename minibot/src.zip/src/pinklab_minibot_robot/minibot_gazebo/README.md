# minibot_gazebo

```shell
$ ros2 launch minibot_bringup bringup_robot_gazebo.launch.py world_name:=simple_building.world
```

<center><img src="../docs/gazebo_simple_building.png" width="70%"></center>